// Run with: npm run seed:admin
// Creates or resets the admin login in the SEPARATE admin database.

require('dotenv').config();

const bcrypt = require('bcryptjs');
const connectDatabases = require('../config/db');
const { initModels } = require('../models');
const { generateAdminId } = require('../utils/generateId');

async function seedAdmin() {
  let mainConn;
  let adminConn;

  try {
    // Connect to both databases
    const connections = await connectDatabases();
    mainConn = connections.mainConn;
    adminConn = connections.adminConn;

    // Initialize models
    const models = initModels(mainConn, adminConn);

    // Admin credentials from .env
    const email = process.env.ADMIN_EMAIL || 'admin@shramsetu.coop';
    const password = process.env.ADMIN_PASSWORD || 'Admin@123';
    const name = process.env.ADMIN_NAME || 'ShramSetu Admin';

    // Check whether admin already exists
    const existing = await models.Admin.findOne({ email });

    if (existing) {
      // Reset password for existing admin
      const passwordHash = await bcrypt.hash(password, 10);

      existing.passwordHash = passwordHash;
      existing.name = name;
      existing.email = email;

      await existing.save();

      console.log('');
      console.log('======================================');
      console.log('ADMIN PASSWORD RESET SUCCESSFULLY');
      console.log('======================================');
      console.log(`Admin ID:  ${existing.adminId}`);
      console.log(`Email:     ${email}`);
      console.log(`Password:  ${password}`);
      console.log('======================================');
      console.log('');
    } else {
      // Create a new admin
      const passwordHash = await bcrypt.hash(password, 10);

      const adminId = await generateAdminId(models);

      const admin = await models.Admin.create({
        adminId,
        name,
        email,
        passwordHash,
      });

      console.log('');
      console.log('======================================');
      console.log('ADMIN CREATED SUCCESSFULLY');
      console.log('======================================');
      console.log(`Admin ID:  ${admin.adminId}`);
      console.log(`Email:     ${email}`);
      console.log(`Password:  ${password}`);
      console.log('======================================');
      console.log('');
    }

  } catch (err) {
    console.error('');
    console.error('======================================');
    console.error('SEEDING ADMIN FAILED');
    console.error('======================================');
    console.error(err);
    console.error('======================================');
    console.error('');

    process.exitCode = 1;

  } finally {
    // Close database connections
    if (mainConn) {
      await mainConn.close();
    }

    if (adminConn) {
      await adminConn.close();
    }
  }
}

seedAdmin();