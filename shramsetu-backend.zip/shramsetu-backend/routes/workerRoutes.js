const express = require('express')
const { getModels } = require('../models')

const router = express.Router()

// GET /api/workers
router.get('/', async (req, res) => {
  try {
    const models = getModels()

    const workers = await models.Worker
      .find({ isActive: true })
      .select('-passwordHash')
      .sort({ createdAt: -1 })
      .lean()

    const formattedWorkers = workers.map((worker) => ({
      id: worker.workerId,

      name: worker.name,
      email: worker.email,
      phone: worker.phone,

      skill: worker.skillCategory || 'Service Worker',

      category: worker.skillCategory
        ? worker.skillCategory.toLowerCase()
        : '',

      verified: worker.isVerified,

      rating: worker.rating || 0,

      experience: worker.experienceYears || 0,

      availability: worker.isAvailable
        ? 'Available Today'
        : 'Currently Unavailable',

      // Fields used by the existing WorkerCard UI
      price: worker.price || 0,
      location: worker.city || 'Location not available',
      cooperative:
        worker.cooperative || 'Registered Cooperative',

      jobsCompleted: worker.jobsCompleted || 0,

      distance: worker.distance ?? 0,

      avatarColor:
        worker.avatarColor || '#1e3a5f',
    }))

    res.status(200).json({
      success: true,
      workers: formattedWorkers,
    })
  } catch (error) {
    console.error('Error fetching workers:', error)

    res.status(500).json({
      success: false,
      message: 'Failed to fetch workers',
    })
  }
})

module.exports = router