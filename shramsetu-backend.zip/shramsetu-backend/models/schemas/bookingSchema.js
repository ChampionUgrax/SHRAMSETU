const { Schema } = require('mongoose');

const bookingSchema = new Schema(
  {
    bookingId: { type: Number, unique: true, required: true }, // 101, 106, 111...

    customerId: { type: Number, required: true }, // references customer.customerId
    workerId: { type: Number, default: null }, // references worker.workerId, null until assigned

    // small snapshot so you don't need a second query to show a booking on screen
    customerSnapshot: { name: String, phone: String },
    workerSnapshot: { name: String, phone: String },

    serviceCategory: { type: String, required: true }, // electrician, plumber, tutor...
    description: String,
    address: String,
    price: Number,
    scheduledAt: Date,

    status: {
      type: String,
      enum: ['pending', 'assigned', 'in_progress', 'completed', 'cancelled'],
      default: 'pending',
    },

    statusHistory: [
      {
        oldStatus: String,
        newStatus: String,
        changedByRole: String, // customer, worker, admin
        changedById: Number,
        changedAt: { type: Date, default: Date.now },
      },
    ],
  },
  { timestamps: true }
);

bookingSchema.index({ customerId: 1 });
bookingSchema.index({ workerId: 1 });

module.exports = bookingSchema;
