/**
 * Writes one entry to the activitylogs collection (main DB).
 * Call this on every register, login, booking creation, status change,
 * or admin action so the full trace is always queryable later.
 */
async function logActivity(models, { userId, role, name, email, action, details }) {
  try {
    await models.ActivityLog.create({ userId, role, name, email, action, details });
  } catch (err) {
    // Never let a logging failure break the actual request
    console.error('Failed to write activity log:', err.message);
  }
}

module.exports = logActivity;
