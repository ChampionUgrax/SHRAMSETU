// Run with: npm run seed:admin
// Creates the first admin login in the SEPARATE admin database.
require('dotenv').config();
const bcrypt = require('bcryptjs');
const connectDatabases = require('../config/db');
const { initModels } = require('../models');
const { generateAdminId } = require('../utils/generateId');

async function seedAdmin() {
  const { mainConn, adminConn } = await connectDatabases();
  const models = initModels(mainConn, adminConn);

  const email = process.env.ADMIN_EMAIL || 'admin@shramsetu.coop';
  const existing = await models.Admin.findOne({ email });

  if (existing) {
    console.log(`Admin already exists in the admin database -> ${email}`);
  } else {
    const passwordHash = await bcrypt.hash(process.env.ADMIN_PASSWORD || 'Admin@123', 10);
    const adminId = await generateAdminId(models);

    const admin = await models.Admin.create({
      adminId,
      name: process.env.ADMIN_NAME || 'ShramSetu Admin',
      email,
      passwordHash,
    });

    console.log('Admin created in the ADMIN database:');
    console.log(`  adminId: ${admin.adminId}`);
    console.log(`  email:   ${admin.email}`);
    console.log(`  password: ${process.env.ADMIN_PASSWORD || 'Admin@123'}`);
  }

  await mainConn.close();
  await adminConn.close();
  process.exit(0);
}

seedAdmin().catch((err) => {
  console.error('Seeding admin failed:', err);
  process.exit(1);
});
