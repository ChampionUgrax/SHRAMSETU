const customerSchema = require('./schemas/customerSchema');
const workerSchema = require('./schemas/workerSchema');
const bookingSchema = require('./schemas/bookingSchema');
const activityLogSchema = require('./schemas/activityLogSchema');
const counterSchema = require('./schemas/counterSchema');
const adminSchema = require('./schemas/adminSchema');

let models = null;

/**
 * Call this ONCE at startup, after both DB connections are open.
 * Binds each schema to the right connection:
 *   mainConn  -> Customer, Worker, Booking, ActivityLog, Counter
 *   adminConn -> Admin, AdminCounter (separate counters collection, admin DB only)
 */
function initModels(mainConn, adminConn) {
  models = {
    // ---- MAIN DATABASE ----
    Customer: mainConn.model('Customer', customerSchema),
    Worker: mainConn.model('Worker', workerSchema),
    Booking: mainConn.model('Booking', bookingSchema),
    ActivityLog: mainConn.model('ActivityLog', activityLogSchema),
    Counter: mainConn.model('Counter', counterSchema),

    // ---- ADMIN DATABASE (completely separate) ----
    Admin: adminConn.model('Admin', adminSchema),
    AdminCounter: adminConn.model('Counter', counterSchema),
  };
  return models;
}

function getModels() {
  if (!models) {
    throw new Error('Models not initialized yet — call initModels() after DB connections open.');
  }
  return models;
}

module.exports = { initModels, getModels };
