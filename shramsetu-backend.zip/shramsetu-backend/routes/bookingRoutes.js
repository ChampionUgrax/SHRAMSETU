const express = require('express');
const router = express.Router();
const {
  createBooking,
  getMyBookingsAsCustomer,
  getMyAssignedBookings,
  getBookingById,
  assignWorker,
  updateBookingStatus,
} = require('../controllers/bookingController');
const { protect, requireRole } = require('../middleware/auth');

router.post('/', protect, requireRole('customer'), createBooking);
router.get('/mine', protect, requireRole('customer'), getMyBookingsAsCustomer);
router.get('/assigned', protect, requireRole('worker'), getMyAssignedBookings);
router.get('/:bookingId', protect, getBookingById);
router.put('/:bookingId/assign', protect, requireRole('admin'), assignWorker);
router.put('/:bookingId/status', protect, requireRole('worker', 'admin'), updateBookingStatus);

module.exports = router;
