# ShramSetu Backend — Two-Database Setup

Admin is now a **completely separate MongoDB database** — not just a separate collection.

```
shramsetu database          (customers, workers, bookings, activitylogs, counters)
shramsetu_admin database    (admins, counters)   <-- fully separate, own connection
```

Nothing else changed from the original requirements: same auto-incrementing ID scheme
(101, 106, 111... +5 each time, atomic, no collisions), same bcrypt password hashing,
same JWT sessions, same full activity trace for every login/action, same admin-only
endpoints to view every customer/worker/booking/log.

---

## 1. Install MongoDB locally (if you haven't already)

**Windows:** download "MongoDB Community Server" from mongodb.com/try/download/community,
install it, check "Install MongoDB as a Service" during setup.

**Verify it's running:**
```bash
mongosh
```
If that opens a prompt, MongoDB is running on `127.0.0.1:27017`.

## 2. Setup

```bash
npm install
cp .env.example .env
```

Open `.env` — the two database URIs are already pointed at your local MongoDB, just two
different database names on the same server:

```
MONGO_URI_MAIN=mongodb://127.0.0.1:27017/shramsetu
MONGO_URI_ADMIN=mongodb://127.0.0.1:27017/shramsetu_admin
JWT_SECRET=shramsetu_super_secret_change_me
PORT=5000
ADMIN_NAME=ShramSetu Admin
ADMIN_EMAIL=admin@shramsetu.coop
ADMIN_PASSWORD=Admin@123
```

Create the first admin (this writes into the `shramsetu_admin` database, not `shramsetu`):
```bash
npm run seed:admin
```
You'll see:
```
Admin created in the ADMIN database:
  adminId: 101
  email:   admin@shramsetu.coop
  password: Admin@123
```

Start the server:
```bash
npm run dev
```
You should see:
```
[MongoDB] Main DB connected -> shramsetu
[MongoDB] Admin DB connected -> shramsetu_admin
[MongoDB] ID counters ready (customerId/workerId/bookingId in main DB, adminId in admin DB — all start at 101, +5 each)
[ShramSetu API] running on http://localhost:5000
```

Test it: open `http://localhost:5000/api/health` in a browser.

## 3. Confirm the split in Compass

Open MongoDB Compass, connect to `mongodb://127.0.0.1:27017`. You'll now see **two separate
databases** in the sidebar:
- `shramsetu` → collections: `customers`, `workers`, `bookings`, `activitylogs`, `counters`
- `shramsetu_admin` → collections: `admins`, `counters` (its own separate counter, only for `adminId`)

They are not linked in any way at the database level — the API is the only thing that
knows how to talk to both.

## 4. Full endpoint reference

| Method | Endpoint | Role | Database touched |
|---|---|---|---|
| POST | `/api/auth/customer/register` | Public | Main |
| POST | `/api/auth/customer/login` | Public | Main |
| POST | `/api/auth/worker/register` | Public | Main |
| POST | `/api/auth/worker/login` | Public | Main |
| POST | `/api/auth/admin/login` | Public | Admin |
| GET | `/api/auth/me` | Any logged-in | Main or Admin (by role) |
| POST | `/api/bookings` | Customer | Main |
| GET | `/api/bookings/mine` | Customer | Main |
| GET | `/api/bookings/assigned` | Worker | Main |
| GET | `/api/bookings/:bookingId` | Any logged-in | Main |
| PUT | `/api/bookings/:bookingId/assign` | Admin | Main (reads Admin token, writes Main) |
| PUT | `/api/bookings/:bookingId/status` | Worker/Admin | Main |
| GET | `/api/admin/customers` | Admin | Main |
| GET | `/api/admin/workers` | Admin | Main |
| PUT | `/api/admin/workers/:workerId/verify` | Admin | Main |
| GET | `/api/admin/bookings` | Admin | Main |
| GET | `/api/admin/logs` | Admin | Main |
| GET | `/api/admin/logs/:role/:userId` | Admin | Main |
| GET | `/api/admin/overview` | Admin | Both (counts from Main + Admin) |

## 5. Quick test flow (Postman)

1. `POST /api/auth/customer/register` → get a token + `customerId` (101, then 106...)
2. `POST /api/auth/worker/register` → get a token + `workerId`
3. `POST /api/auth/admin/login` with the seeded admin email/password → get admin token
4. `POST /api/bookings` (as customer) → creates a booking, get `bookingId`
5. `PUT /api/bookings/:bookingId/assign` (as admin) → body `{ "workerId": 101 }`
6. `PUT /api/bookings/:bookingId/status` (as worker) → body `{ "status": "completed" }`
7. `GET /api/admin/overview` (as admin) → counts pulled from both databases at once
8. `GET /api/admin/logs/customer/101` (as admin) → full trace for that one customer

## 6. Project structure

```
shramsetu-backend/
├── config/db.js               # opens BOTH database connections
├── models/
│   ├── index.js                # binds each schema to the right connection
│   └── schemas/                # plain schema definitions (not bound to a DB)
│       ├── customerSchema.js   # -> main DB
│       ├── workerSchema.js     # -> main DB
│       ├── bookingSchema.js    # -> main DB
│       ├── activityLogSchema.js # -> main DB
│       ├── adminSchema.js      # -> admin DB
│       └── counterSchema.js    # used in BOTH DBs (separate collections)
├── middleware/auth.js
├── controllers/
├── routes/
├── utils/
│   ├── generateId.js           # 101, 106, 111... generator
│   ├── logActivity.js
│   └── seedAdmin.js            # writes into the ADMIN database
├── server.js
└── .env.example
```

## 7. Going live later

Swap `MONGO_URI_MAIN` and `MONGO_URI_ADMIN` to two Atlas connection strings (can be the
same cluster, different database name — or genuinely two different clusters for full
isolation). No other code changes needed.
