const express = require('express');
const router = express.Router();
const {
  getAllCustomers,
  getAllWorkers,
  updateWorkerStatus,
  getAllBookings,
  getLogs,
  getLogsForUser,
  getOverview,
} = require('../controllers/adminController');
const { protect, requireRole } = require('../middleware/auth');

router.use(protect, requireRole('admin'));

router.get('/customers', getAllCustomers);
router.get('/workers', getAllWorkers);
router.put('/workers/:workerId/verify', updateWorkerStatus);
router.get('/bookings', getAllBookings);
router.get('/logs', getLogs);
router.get('/logs/:role/:userId', getLogsForUser);
router.get('/overview', getOverview);

module.exports = router;
