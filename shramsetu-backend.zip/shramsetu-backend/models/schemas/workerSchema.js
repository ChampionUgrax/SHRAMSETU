const mongoose = require('mongoose');

const { Schema } = mongoose;

const workerSchema = new Schema(
  {
    workerId: {
      type: Number,
      unique: true,
      required: true,
    },

    name: {
      type: String,
      required: true,
    },

    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },

    phone: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },

    passwordHash: {
      type: String,
      required: true,
    },

    skillCategory: String,

    experienceYears: Number,

    rating: {
      type: Number,
      default: 0,
    },

    isVerified: {
      type: Boolean,
      default: false,
    },

    isAvailable: {
      type: Boolean,
      default: true,
    },

    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

workerSchema.methods.toSafeObject = function () {
  const obj = this.toObject();

  delete obj.passwordHash;

  return obj;
};

module.exports = workerSchema;