// Run with: node utils/seedCustomer.js
// Creates or resets a demo customer account.

require('dotenv').config();

const bcrypt = require('bcryptjs');
const connectDatabases = require('../config/db');
const { initModels } = require('../models');
const { generateCustomerId } = require('../utils/generateId');

async function seedCustomer() {
  let mainConn;
  let adminConn;

  try {
    const connections = await connectDatabases();

    mainConn = connections.mainConn;
    adminConn = connections.adminConn;

    const models = initModels(mainConn, adminConn);

    const email = 'customer@gmail.com';
    const password = '123456';
    const name = 'Test Customer';

    const existing = await models.Customer.findOne({ email });

    if (existing) {
      const passwordHash = await bcrypt.hash(password, 10);

      existing.passwordHash = passwordHash;
      existing.name = name;
      existing.phone = '9876543210';
      existing.address = 'Test Address';
      existing.city = 'Vadodara';
      existing.pincode = '390001';
      existing.isActive = true;

      await existing.save();

      console.log('');
      console.log('======================================');
      console.log('CUSTOMER RESET SUCCESSFULLY');
      console.log('======================================');
      console.log(`Customer ID: ${existing.customerId}`);
      console.log(`Email:       ${email}`);
      console.log(`Password:    ${password}`);
      console.log('======================================');
      console.log('');
    } else {
      const passwordHash = await bcrypt.hash(password, 10);

      const customerId = await generateCustomerId(models);

      const customer = await models.Customer.create({
        customerId,
        name,
        email,
        phone: '9876543210',
        address: 'Test Address',
        city: 'Vadodara',
        pincode: '390001',
        passwordHash,
        isActive: true,
      });

      console.log('');
      console.log('======================================');
      console.log('CUSTOMER CREATED SUCCESSFULLY');
      console.log('======================================');
      console.log(`Customer ID: ${customer.customerId}`);
      console.log(`Email:       ${email}`);
      console.log(`Password:    ${password}`);
      console.log('======================================');
      console.log('');
    }

  } catch (err) {
    console.error('');
    console.error('CUSTOMER SEEDING FAILED');
    console.error(err);
    console.error('');

    process.exitCode = 1;

  } finally {
    if (mainConn) {
      await mainConn.close();
    }

    if (adminConn) {
      await adminConn.close();
    }
  }
}

seedCustomer();