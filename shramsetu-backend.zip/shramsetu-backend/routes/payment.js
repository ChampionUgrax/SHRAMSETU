const express = require("express");
const crypto = require("crypto");
const Razorpay = require("razorpay");

const router = express.Router();

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

/*
 * CREATE ORDER
 */
router.post("/create-order", async (req, res) => {
  try {
    const {
      amount,
      bookingId,
    } = req.body;

    if (!amount || Number(amount) <= 0) {
      return res.status(400).json({
        success: false,
        message: "Invalid amount.",
      });
    }

    const amountInPaise = Math.round(
      Number(amount) * 100
    );

    const order =
      await razorpay.orders.create({
        amount: amountInPaise,
        currency: "INR",
        receipt:
          `booking_${bookingId || Date.now()}`,
        notes: {
          bookingId:
            bookingId || "",
        },
      });

    res.json({
      success: true,
      order,
    });
  } catch (error) {
    console.error(
      "Create order error:",
      error
    );

    res.status(500).json({
      success: false,
      message:
        "Unable to create Razorpay order.",
    });
  }
});

/*
 * VERIFY PAYMENT
 */
router.post("/verify", async (req, res) => {
  try {
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
    } = req.body;

    if (
      !razorpay_order_id ||
      !razorpay_payment_id ||
      !razorpay_signature
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Incomplete payment details.",
      });
    }

    const generatedSignature =
      crypto
        .createHmac(
          "sha256",
          process.env.RAZORPAY_KEY_SECRET
        )
        .update(
          `${razorpay_order_id}|${razorpay_payment_id}`
        )
        .digest("hex");

    if (
      generatedSignature !==
      razorpay_signature
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Payment signature verification failed.",
      });
    }

    res.json({
      success: true,
      message:
        "Payment verified successfully.",
      orderId:
        razorpay_order_id,
      paymentId:
        razorpay_payment_id,
    });
  } catch (error) {
    console.error(
      "Verify payment error:",
      error
    );

    res.status(500).json({
      success: false,
      message:
        "Unable to verify payment.",
    });
  }
});

module.exports = router;