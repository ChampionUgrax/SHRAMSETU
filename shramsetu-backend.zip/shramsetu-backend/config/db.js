const mongoose = require('mongoose');

/**
 * Opens TWO independent MongoDB connections:
 *  - mainConn  -> customers, workers, bookings, activitylogs, counters
 *  - adminConn -> admins, and its own separate counters collection
 * They can point at the same MongoDB server (different database names)
 * or completely different servers/clusters — doesn't matter, they're
 * fully independent connections.
 */
function connectDatabases() {
  const mainConn = mongoose.createConnection(process.env.MONGO_URI_MAIN);
  const adminConn = mongoose.createConnection(process.env.MONGO_URI_ADMIN);

  const waitForOpen = (conn, label) =>
    new Promise((resolve, reject) => {
      conn.once('open', () => {
        console.log(`[MongoDB] ${label} connected -> ${conn.name}`);
        resolve();
      });
      conn.once('error', (err) => reject(err));
    });

  return Promise.all([
    waitForOpen(mainConn, 'Main DB'),
    waitForOpen(adminConn, 'Admin DB'),
  ]).then(() => ({ mainConn, adminConn }));
}

module.exports = connectDatabases;
