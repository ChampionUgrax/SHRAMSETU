const { Schema } = require('mongoose');

// This exact schema is used in both the main DB and the admin DB —
// each database gets its OWN counters collection, so customerId/workerId/
// bookingId counters (main DB) are totally separate from adminId counters
// (admin DB). No shared state between the two.
const counterSchema = new Schema({
  _id: { type: String, required: true }, // e.g. "customerId", "workerId", "bookingId", "adminId"
  seq: { type: Number, required: true },
});

module.exports = counterSchema;
