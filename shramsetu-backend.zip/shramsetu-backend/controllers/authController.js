const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { getModels } = require('../models');
const { generateCustomerId, generateWorkerId } = require('../utils/generateId');
const logActivity = require('../utils/logActivity');

function signToken({ mongoId, businessId, role, name, email }) {
  return jwt.sign({ mongoId, businessId, role, name, email }, process.env.JWT_SECRET, {
    expiresIn: '7d',
  });
}

// ---------------- CUSTOMER ----------------

// POST /api/auth/customer/register
exports.registerCustomer = async (req, res) => {
  try {
    const models = getModels();
    const { name, email, phone, password, address, city, pincode } = req.body;
    if (!name || !email || !phone || !password) {
      return res.status(400).json({ message: 'name, email, phone, and password are required' });
    }

    const existing = await models.Customer.findOne({ $or: [{ email }, { phone }] });
    if (existing) return res.status(409).json({ message: 'A customer with this email or phone already exists' });

    const passwordHash = await bcrypt.hash(password, 10);
    const customerId = await generateCustomerId(models);

    const customer = await models.Customer.create({
      customerId, name, email, phone, passwordHash, address, city, pincode,
    });

    await logActivity(models, {
      userId: customerId, role: 'customer', name, email, action: 'register',
    });

    const token = signToken({ mongoId: customer._id, businessId: customerId, role: 'customer', name, email });
    res.status(201).json({ token, user: customer.toSafeObject() });
  } catch (err) {
    res.status(500).json({ message: 'Customer registration failed', error: err.message });
  }
};

// POST /api/auth/customer/login
exports.loginCustomer = async (req, res) => {
  try {
    const models = getModels();
    const { email, password } = req.body;
    const customer = await models.Customer.findOne({ email });
    if (!customer || !customer.isActive) return res.status(401).json({ message: 'Invalid credentials' });

    const match = await bcrypt.compare(password, customer.passwordHash);
    if (!match) return res.status(401).json({ message: 'Invalid credentials' });

    await logActivity(models, {
      userId: customer.customerId, role: 'customer', name: customer.name, email: customer.email, action: 'login',
    });

    const token = signToken({
      mongoId: customer._id, businessId: customer.customerId, role: 'customer',
      name: customer.name, email: customer.email,
    });
    res.json({ token, user: customer.toSafeObject() });
  } catch (err) {
    res.status(500).json({ message: 'Customer login failed', error: err.message });
  }
};

// ---------------- WORKER ----------------

// POST /api/auth/worker/register
exports.registerWorker = async (req, res) => {
  try {
    const models = getModels();
    const { name, email, phone, password, skillCategory, experienceYears } = req.body;
    if (!name || !email || !phone || !password) {
      return res.status(400).json({ message: 'name, email, phone, and password are required' });
    }

    const existing = await models.Worker.findOne({ $or: [{ email }, { phone }] });
    if (existing) return res.status(409).json({ message: 'A worker with this email or phone already exists' });

    const passwordHash = await bcrypt.hash(password, 10);
    const workerId = await generateWorkerId(models);

    const worker = await models.Worker.create({
      workerId, name, email, phone, passwordHash, skillCategory, experienceYears,
    });

    await logActivity(models, {
      userId: workerId, role: 'worker', name, email, action: 'register',
    });

    const token = signToken({ mongoId: worker._id, businessId: workerId, role: 'worker', name, email });
    res.status(201).json({ token, user: worker.toSafeObject() });
  } catch (err) {
    res.status(500).json({ message: 'Worker registration failed', error: err.message });
  }
};

// POST /api/auth/worker/login
exports.loginWorker = async (req, res) => {
  try {
    const models = getModels();
    const { email, password } = req.body;
    const worker = await models.Worker.findOne({ email });
    if (!worker || !worker.isActive) return res.status(401).json({ message: 'Invalid credentials' });

    const match = await bcrypt.compare(password, worker.passwordHash);
    if (!match) return res.status(401).json({ message: 'Invalid credentials' });

    await logActivity(models, {
      userId: worker.workerId, role: 'worker', name: worker.name, email: worker.email, action: 'login',
    });

    const token = signToken({
      mongoId: worker._id, businessId: worker.workerId, role: 'worker',
      name: worker.name, email: worker.email,
    });
    res.json({ token, user: worker.toSafeObject() });
  } catch (err) {
    res.status(500).json({ message: 'Worker login failed', error: err.message });
  }
};

// ---------------- ADMIN ----------------
// No public register route — admins are created only via `npm run seed:admin`.

// POST /api/auth/admin/login
exports.loginAdmin = async (req, res) => {
  try {
    const models = getModels();
    const { email, password } = req.body;
    const admin = await models.Admin.findOne({ email });
    if (!admin || !admin.isActive) return res.status(401).json({ message: 'Invalid credentials' });

    const match = await bcrypt.compare(password, admin.passwordHash);
    if (!match) return res.status(401).json({ message: 'Invalid credentials' });

    // Admin logins are still recorded in the MAIN db's activitylogs,
    // so a single "who logged in when" trail exists across all roles.
    await logActivity(models, {
      userId: admin.adminId, role: 'admin', name: admin.name, email: admin.email, action: 'login',
    });

    const token = signToken({
      mongoId: admin._id, businessId: admin.adminId, role: 'admin',
      name: admin.name, email: admin.email,
    });
    res.json({ token, user: admin.toSafeObject() });
  } catch (err) {
    res.status(500).json({ message: 'Admin login failed', error: err.message });
  }
};

// ---------------- LOGOUT (all roles) ----------------
// JWTs are stateless, so there's no server-side session to destroy — but we
// still record the logout event so admin sees a complete login/logout trail
// for every customer and worker, not just logins.

// POST /api/auth/customer/logout
exports.logoutCustomer = async (req, res) => {
  const models = getModels();
  await logActivity(models, {
    userId: req.user.businessId, role: 'customer', name: req.user.name, email: req.user.email, action: 'logout',
  });
  res.json({ message: 'Logged out' });
};

// POST /api/auth/worker/logout
exports.logoutWorker = async (req, res) => {
  const models = getModels();
  await logActivity(models, {
    userId: req.user.businessId, role: 'worker', name: req.user.name, email: req.user.email, action: 'logout',
  });
  res.json({ message: 'Logged out' });
};

// POST /api/auth/admin/logout
exports.logoutAdmin = async (req, res) => {
  const models = getModels();
  await logActivity(models, {
    userId: req.user.businessId, role: 'admin', name: req.user.name, email: req.user.email, action: 'logout',
  });
  res.json({ message: 'Logged out' });
};

// GET /api/auth/me  (works for any logged-in role)
exports.getMe = async (req, res) => {
  try {
    const models = getModels();
    const { role, mongoId } = req.user;
    let user;
    if (role === 'customer') user = await models.Customer.findById(mongoId);
    else if (role === 'worker') user = await models.Worker.findById(mongoId);
    else if (role === 'admin') user = await models.Admin.findById(mongoId);

    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json(user.toSafeObject());
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch profile', error: err.message });
  }
};
