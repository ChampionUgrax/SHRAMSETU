const { getModels } = require('../models');
const { generateBookingId } = require('../utils/generateId');
const logActivity = require('../utils/logActivity');

// POST /api/bookings  (customer creates a booking)
exports.createBooking = async (req, res) => {
  try {
    const models = getModels();
    const { serviceCategory, description, address, scheduledAt, price } = req.body;
    if (!serviceCategory || !address) {
      return res.status(400).json({ message: 'serviceCategory and address are required' });
    }

    const customer = await models.Customer.findById(req.user.mongoId);
    if (!customer) return res.status(404).json({ message: 'Customer not found' });

    const bookingId = await generateBookingId(models);

    const booking = await models.Booking.create({
      bookingId,
      customerId: customer.customerId,
      customerSnapshot: { name: customer.name, phone: customer.phone },
      serviceCategory,
      description,
      address,
      scheduledAt,
      price,
      status: 'pending',
    });

    await logActivity(models, {
      userId: customer.customerId, role: 'customer', name: customer.name, email: customer.email,
      action: 'booking_created', details: { bookingId, serviceCategory },
    });

    res.status(201).json(booking);
  } catch (err) {
    res.status(500).json({ message: 'Failed to create booking', error: err.message });
  }
};

// GET /api/bookings/mine  (customer: own bookings)
exports.getMyBookingsAsCustomer = async (req, res) => {
  try {
    const models = getModels();
    const bookings = await models.Booking.find({ customerId: req.user.businessId }).sort({ createdAt: -1 });
    res.json(bookings);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch bookings', error: err.message });
  }
};

// GET /api/bookings/assigned  (worker: jobs assigned to them)
exports.getMyAssignedBookings = async (req, res) => {
  try {
    const models = getModels();
    const bookings = await models.Booking.find({ workerId: req.user.businessId }).sort({ createdAt: -1 });
    res.json(bookings);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch assigned bookings', error: err.message });
  }
};

// GET /api/bookings/:bookingId  (lookup by numeric booking id)
exports.getBookingById = async (req, res) => {
  try {
    const models = getModels();
    const booking = await models.Booking.findOne({ bookingId: Number(req.params.bookingId) });
    if (!booking) return res.status(404).json({ message: 'Booking not found' });
    res.json(booking);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch booking', error: err.message });
  }
};

// PUT /api/bookings/:bookingId/assign  (admin assigns a worker)
// body: { workerId }
exports.assignWorker = async (req, res) => {
  try {
    const models = getModels();
    const { workerId } = req.body;

    const booking = await models.Booking.findOne({ bookingId: Number(req.params.bookingId) });
    if (!booking) return res.status(404).json({ message: 'Booking not found' });

    const worker = await models.Worker.findOne({ workerId });
    if (!worker) return res.status(404).json({ message: 'Worker not found' });

    booking.statusHistory.push({
      oldStatus: booking.status, newStatus: 'assigned',
      changedByRole: 'admin', changedById: req.user.businessId,
    });
    booking.workerId = worker.workerId;
    booking.workerSnapshot = { name: worker.name, phone: worker.phone };
    booking.status = 'assigned';
    await booking.save();

    await logActivity(models, {
      userId: req.user.businessId, role: 'admin', name: req.user.name, email: req.user.email,
      action: 'worker_assigned', details: { bookingId: booking.bookingId, workerId: worker.workerId },
    });

    res.json(booking);
  } catch (err) {
    res.status(500).json({ message: 'Failed to assign worker', error: err.message });
  }
};

// PUT /api/bookings/:bookingId/status  (worker or admin updates status)
exports.updateBookingStatus = async (req, res) => {
  try {
    const models = getModels();
    const { status } = req.body;
    const validStatuses = ['pending', 'assigned', 'in_progress', 'completed', 'cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ message: `status must be one of: ${validStatuses.join(', ')}` });
    }

    const booking = await models.Booking.findOne({ bookingId: Number(req.params.bookingId) });
    if (!booking) return res.status(404).json({ message: 'Booking not found' });

    booking.statusHistory.push({
      oldStatus: booking.status, newStatus: status,
      changedByRole: req.user.role, changedById: req.user.businessId,
    });
    booking.status = status;
    await booking.save();

    await logActivity(models, {
      userId: req.user.businessId, role: req.user.role, name: req.user.name, email: req.user.email,
      action: 'status_changed', details: { bookingId: booking.bookingId, newStatus: status },
    });

    res.json(booking);
  } catch (err) {
    res.status(500).json({ message: 'Failed to update booking status', error: err.message });
  }
};
