const { Schema } = require('mongoose');

const customerSchema = new Schema(
  {
    customerId: { type: Number, unique: true, required: true }, // 101, 106, 111...
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    phone: { type: String, required: true, unique: true, trim: true },
    passwordHash: { type: String, required: true },
    address: String,
    city: String,
    pincode: String,
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

customerSchema.methods.toSafeObject = function () {
  const obj = this.toObject();
  delete obj.passwordHash;
  return obj;
};

module.exports = customerSchema;
