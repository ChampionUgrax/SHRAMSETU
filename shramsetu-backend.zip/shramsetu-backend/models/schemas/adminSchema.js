const { Schema } = require('mongoose');

// This schema is compiled against the ADMIN database connection only.
// Nothing else (customers/workers/bookings) lives alongside it.
const adminSchema = new Schema(
  {
    adminId: { type: Number, unique: true, required: true }, // 101, 106, 111...
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    phone: String,
    passwordHash: { type: String, required: true },
    role: { type: String, default: 'admin' },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

adminSchema.methods.toSafeObject = function () {
  const obj = this.toObject();
  delete obj.passwordHash;
  return obj;
};

module.exports = adminSchema;
