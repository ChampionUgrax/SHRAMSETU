require('dotenv').config()

const mongoose = require('mongoose')
const bcrypt = require('bcryptjs')

const workerSchema = require('../models/schemas/workerSchema')

const Worker = mongoose.model('Worker', workerSchema)

const workers = [
  {
    workerId: 101,
    name: 'Rajesh Kumar',
    email: 'rajesh@shramsetu.in',
    phone: '9876500001',
    password: '123456',
    skillCategory: 'Electrician',
    experienceYears: 9,
    rating: 4.8,
    isVerified: true,
    isAvailable: true,
    isActive: true,
    city: 'Vadodara',
    price: 250,
    cooperative: 'ShramSetu Cooperative',
    jobsCompleted: 128,
  },

  {
    workerId: 102,
    name: 'Priya Sharma',
    email: 'priya@shramsetu.in',
    phone: '9876500002',
    password: '123456',
    skillCategory: 'Caregiver',
    experienceYears: 6,
    rating: 4.9,
    isVerified: true,
    isAvailable: true,
    isActive: true,
    city: 'Vadodara',
    price: 400,
    cooperative: 'ShramSetu Cooperative',
    jobsCompleted: 96,
  },

  {
    workerId: 103,
    name: 'Amit Verma',
    email: 'amit@shramsetu.in',
    phone: '9876500003',
    password: '123456',
    skillCategory: 'Plumber',
    experienceYears: 7,
    rating: 4.6,
    isVerified: true,
    isAvailable: true,
    isActive: true,
    city: 'Vadodara',
    price: 220,
    cooperative: 'ShramSetu Cooperative',
    jobsCompleted: 84,
  },

  {
    workerId: 104,
    name: 'Sunita Devi',
    email: 'sunita@shramsetu.in',
    phone: '9876500004',
    password: '123456',
    skillCategory: 'Cleaner',
    experienceYears: 5,
    rating: 4.7,
    isVerified: true,
    isAvailable: true,
    isActive: true,
    city: 'Vadodara',
    price: 180,
    cooperative: 'ShramSetu Cooperative',
    jobsCompleted: 73,
  },

  {
    workerId: 105,
    name: 'Mohammed Arif',
    email: 'arif@shramsetu.in',
    phone: '9876500005',
    password: '123456',
    skillCategory: 'Carpenter',
    experienceYears: 11,
    rating: 4.5,
    isVerified: true,
    isAvailable: true,
    isActive: true,
    city: 'Vadodara',
    price: 300,
    cooperative: 'ShramSetu Cooperative',
    jobsCompleted: 112,
  },

  {
    workerId: 106,
    name: 'Ravi Singh',
    email: 'ravi@shramsetu.in',
    phone: '9876500006',
    password: '123456',
    skillCategory: 'Painter',
    experienceYears: 8,
    rating: 4.4,
    isVerified: true,
    isAvailable: true,
    isActive: true,
    city: 'Vadodara',
    price: 260,
    cooperative: 'ShramSetu Cooperative',
    jobsCompleted: 67,
  },

  {
    workerId: 107,
    name: 'Meena Patel',
    email: 'meena@shramsetu.in',
    phone: '9876500007',
    password: '123456',
    skillCategory: 'Cleaner',
    experienceYears: 4,
    rating: 4.6,
    isVerified: true,
    isAvailable: true,
    isActive: true,
    city: 'Vadodara',
    price: 180,
    cooperative: 'ShramSetu Cooperative',
    jobsCompleted: 59,
  },

  {
    workerId: 108,
    name: 'Arjun Yadav',
    email: 'arjun@shramsetu.in',
    phone: '9876500008',
    password: '123456',
    skillCategory: 'Technician',
    experienceYears: 6,
    rating: 4.7,
    isVerified: true,
    isAvailable: true,
    isActive: true,
    city: 'Vadodara',
    price: 280,
    cooperative: 'ShramSetu Cooperative',
    jobsCompleted: 81,
  },
]

async function seedWorkers() {
  try {
    await mongoose.connect(process.env.MONGO_URI_MAIN)

    console.log('Connected to MongoDB')

    await Worker.deleteMany({})

    console.log('Old workers removed')

    const workersWithPasswords = await Promise.all(
      workers.map(async (worker) => {
        const passwordHash = await bcrypt.hash(
          worker.password,
          10
        )

        return {
          workerId: worker.workerId,
          name: worker.name,
          email: worker.email,
          phone: worker.phone,
          passwordHash,

          skillCategory: worker.skillCategory,
          experienceYears: worker.experienceYears,
          rating: worker.rating,

          isVerified: worker.isVerified,
          isAvailable: worker.isAvailable,
          isActive: worker.isActive,

          city: worker.city,
          price: worker.price,
          cooperative: worker.cooperative,
          jobsCompleted: worker.jobsCompleted,
        }
      })
    )

    await Worker.insertMany(workersWithPasswords)

    console.log('8 workers inserted successfully')

    console.log('')
    console.log('Worker login credentials:')
    console.log('Email: rajesh@shramsetu.in')
    console.log('Password: 123456')
    console.log('')
    console.log('All seeded workers use password: 123456')

    await mongoose.disconnect()

    console.log('MongoDB connection closed')
    console.log('Worker seeding completed successfully')

    process.exit(0)
  } catch (error) {
    console.error('Error seeding workers:')
    console.error(error)

    try {
      await mongoose.disconnect()
    } catch {}

    process.exit(1)
  }
}

seedWorkers()