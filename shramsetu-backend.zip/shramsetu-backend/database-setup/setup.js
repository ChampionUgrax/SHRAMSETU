// Standalone database creation script — no Express, no Mongoose, no API framework.
// Run this once (or safely re-run anytime) to fully materialize both databases:
// collections, $jsonSchema validation enforced BY MONGODB ITSELF, indexes, and
// the first admin account. Whatever stack your API engineer uses (Mongoose,
// native driver, Prisma, etc.) just connects afterward — the database is
// already correct on its own.
//
// Run with: npm run setup

require('dotenv').config();
const { MongoClient } = require('mongodb');
const bcrypt = require('bcryptjs');

// ---------------------------------------------------------------------------
// SCHEMAS (enforced at the MongoDB level via $jsonSchema validators)
// ---------------------------------------------------------------------------

const customerSchema = {
  bsonType: 'object',
  required: ['customerId', 'name', 'email', 'phone', 'passwordHash', 'isActive', 'createdAt', 'updatedAt'],
  properties: {
    customerId: { bsonType: 'number', description: 'unique sequential id: 101, 106, 111...' },
    name: { bsonType: 'string' },
    email: { bsonType: 'string' },
    phone: { bsonType: 'string' },
    passwordHash: { bsonType: 'string' },
    address: { bsonType: ['string', 'null'] },
    city: { bsonType: ['string', 'null'] },
    pincode: { bsonType: ['string', 'null'] },
    isActive: { bsonType: 'bool' },
    createdAt: { bsonType: 'date' },
    updatedAt: { bsonType: 'date' },
  },
};

const workerSchema = {
  bsonType: 'object',
  required: ['workerId', 'name', 'email', 'phone', 'passwordHash', 'isActive', 'createdAt', 'updatedAt'],
  properties: {
    workerId: { bsonType: 'number' },
    name: { bsonType: 'string' },
    email: { bsonType: 'string' },
    phone: { bsonType: 'string' },
    passwordHash: { bsonType: 'string' },
    skillCategory: { bsonType: ['string', 'null'] },
    experienceYears: { bsonType: ['number', 'null'] },
    rating: { bsonType: ['number', 'null'] },
    isVerified: { bsonType: 'bool' },
    isAvailable: { bsonType: 'bool' },
    isActive: { bsonType: 'bool' },
    createdAt: { bsonType: 'date' },
    updatedAt: { bsonType: 'date' },
  },
};

const bookingSchema = {
  bsonType: 'object',
  required: ['bookingId', 'customerId', 'serviceCategory', 'address', 'status', 'createdAt', 'updatedAt'],
  properties: {
    bookingId: { bsonType: 'number' },
    customerId: { bsonType: 'number' },
    workerId: { bsonType: ['number', 'null'] },
    serviceCategory: { bsonType: 'string' },
    description: { bsonType: ['string', 'null'] },
    address: { bsonType: 'string' },
    price: { bsonType: ['number', 'null'] },
    scheduledAt: { bsonType: ['date', 'null'] },
    status: { enum: ['pending', 'assigned', 'in_progress', 'completed', 'cancelled'] },
    createdAt: { bsonType: 'date' },
    updatedAt: { bsonType: 'date' },
  },
};

const activityLogSchema = {
  bsonType: 'object',
  required: ['userId', 'role', 'action', 'createdAt'],
  properties: {
    userId: { bsonType: 'number' },
    role: { enum: ['customer', 'worker', 'admin'] },
    name: { bsonType: ['string', 'null'] },
    email: { bsonType: ['string', 'null'] },
    action: { bsonType: 'string' },
    details: {},
    createdAt: { bsonType: 'date' },
  },
};

const counterSchema = {
  bsonType: 'object',
  required: ['_id', 'seq'],
  properties: {
    _id: { bsonType: 'string' },
    seq: { bsonType: 'number' },
  },
};

const adminSchema = {
  bsonType: 'object',
  required: ['adminId', 'name', 'email', 'passwordHash', 'role', 'isActive', 'createdAt', 'updatedAt'],
  properties: {
    adminId: { bsonType: 'number' },
    name: { bsonType: 'string' },
    email: { bsonType: 'string' },
    phone: { bsonType: ['string', 'null'] },
    passwordHash: { bsonType: 'string' },
    role: { bsonType: 'string' },
    isActive: { bsonType: 'bool' },
    createdAt: { bsonType: 'date' },
    updatedAt: { bsonType: 'date' },
  },
};

// ---------------------------------------------------------------------------
// HELPERS
// ---------------------------------------------------------------------------

async function ensureCollection(db, name, jsonSchema) {
  const existing = await db.listCollections({ name }).toArray();
  if (existing.length === 0) {
    await db.createCollection(name, {
      validator: { $jsonSchema: jsonSchema },
      validationLevel: 'moderate', // validates new inserts/updates, won't break pre-existing bad docs
    });
    console.log(`  + created collection "${name}" with schema validation`);
  } else {
    await db.command({
      collMod: name,
      validator: { $jsonSchema: jsonSchema },
      validationLevel: 'moderate',
    });
    console.log(`  ~ collection "${name}" already existed — validator refreshed`);
  }
}

async function ensureIndex(db, collectionName, indexSpec, options = {}) {
  await db.collection(collectionName).createIndex(indexSpec, options);
  console.log(`  + index on "${collectionName}": ${JSON.stringify(indexSpec)}${options.unique ? ' (unique)' : ''}`);
}

// ---------------------------------------------------------------------------
// MAIN DATABASE: customers, workers, bookings, activitylogs, counters
// ---------------------------------------------------------------------------

async function setupMainDatabase() {
  const client = new MongoClient(process.env.MONGO_URI_MAIN);
  await client.connect();
  const db = client.db();
  console.log(`\nSetting up MAIN database: "${db.databaseName}"`);

  await ensureCollection(db, 'customers', customerSchema);
  await ensureCollection(db, 'workers', workerSchema);
  await ensureCollection(db, 'bookings', bookingSchema);
  await ensureCollection(db, 'activitylogs', activityLogSchema);
  await ensureCollection(db, 'counters', counterSchema);

  await ensureIndex(db, 'customers', { customerId: 1 }, { unique: true });
  await ensureIndex(db, 'customers', { email: 1 }, { unique: true });
  await ensureIndex(db, 'customers', { phone: 1 }, { unique: true });

  await ensureIndex(db, 'workers', { workerId: 1 }, { unique: true });
  await ensureIndex(db, 'workers', { email: 1 }, { unique: true });
  await ensureIndex(db, 'workers', { phone: 1 }, { unique: true });
  await ensureIndex(db, 'workers', { skillCategory: 1 });

  await ensureIndex(db, 'bookings', { bookingId: 1 }, { unique: true });
  await ensureIndex(db, 'bookings', { customerId: 1 });
  await ensureIndex(db, 'bookings', { workerId: 1 });
  await ensureIndex(db, 'bookings', { status: 1 });

  await ensureIndex(db, 'activitylogs', { userId: 1, role: 1 });
  await ensureIndex(db, 'activitylogs', { createdAt: -1 });

  await client.close();
  console.log('MAIN database ready.');
}

// ---------------------------------------------------------------------------
// ADMIN DATABASE: admins, counters (fully separate from main)
// ---------------------------------------------------------------------------

async function setupAdminDatabase() {
  const client = new MongoClient(process.env.MONGO_URI_ADMIN);
  await client.connect();
  const db = client.db();
  console.log(`\nSetting up ADMIN database: "${db.databaseName}"`);

  await ensureCollection(db, 'admins', adminSchema);
  await ensureCollection(db, 'counters', counterSchema);

  await ensureIndex(db, 'admins', { adminId: 1 }, { unique: true });
  await ensureIndex(db, 'admins', { email: 1 }, { unique: true });

  // Seed the first admin login, only if one doesn't already exist
  const adminsCol = db.collection('admins');
  const countersCol = db.collection('counters');
  const email = process.env.ADMIN_EMAIL || 'admin@shramsetu.coop';

  const existingAdmin = await adminsCol.findOne({ email });
  if (existingAdmin) {
    console.log(`  Admin already exists -> ${email} (adminId: ${existingAdmin.adminId})`);
  } else {
    const passwordHash = await bcrypt.hash(process.env.ADMIN_PASSWORD || 'Admin@123', 10);

    // Same atomic 101, then +5 each time rule the API layer uses
    let adminId;
    try {
      await countersCol.insertOne({ _id: 'adminId', seq: 101 });
      adminId = 101;
    } catch (err) {
      if (err.code !== 11000) throw err;
      const result = await countersCol.findOneAndUpdate(
        { _id: 'adminId' },
        { $inc: { seq: 5 } },
        { returnDocument: 'after' }
      );
      adminId = result.value.seq;
    }

    const now = new Date();
    await adminsCol.insertOne({
      adminId,
      name: process.env.ADMIN_NAME || 'ShramSetu Admin',
      email,
      phone: null,
      passwordHash,
      role: 'admin',
      isActive: true,
      createdAt: now,
      updatedAt: now,
    });
    console.log(`  + created first admin -> adminId: ${adminId}, email: ${email}, password: ${process.env.ADMIN_PASSWORD || 'Admin@123'}`);
  }

  await client.close();
  console.log('ADMIN database ready.');
}

// ---------------------------------------------------------------------------

(async () => {
  try {
    await setupMainDatabase();
    await setupAdminDatabase();
    console.log('\nBoth databases are fully set up: collections, validation rules, indexes, and the first admin account all in place.');
    console.log('Hand off MONGO_URI_MAIN and MONGO_URI_ADMIN to your API engineer — nothing else needs to change on the database side.');
    process.exit(0);
  } catch (err) {
    console.error('\nDatabase setup failed:', err.message);
    process.exit(1);
  }
})();
