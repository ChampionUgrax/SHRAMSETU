const express = require('express');
const router = express.Router();
const {
  registerCustomer, loginCustomer, logoutCustomer,
  registerWorker, loginWorker, logoutWorker,
  loginAdmin, logoutAdmin,
  getMe,
} = require('../controllers/authController');
const { protect } = require('../middleware/auth');

router.post('/customer/register', registerCustomer);
router.post('/customer/login', loginCustomer);
router.post('/customer/logout', protect, logoutCustomer);

router.post('/worker/register', registerWorker);
router.post('/worker/login', loginWorker);
router.post('/worker/logout', protect, logoutWorker);

// No admin register route on purpose — admins are created via `npm run seed:admin`
router.post('/admin/login', loginAdmin);
router.post('/admin/logout', protect, logoutAdmin);

router.get('/me', protect, getMe);

module.exports = router;
