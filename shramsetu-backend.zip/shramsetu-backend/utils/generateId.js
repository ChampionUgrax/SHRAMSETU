/**
 * Generates the next id for a given counter name, starting at `start` and
 * incrementing by `step` each time (default: 101, 106, 111, 116...).
 *
 * Works against WHICHEVER Counter model you pass in — pass the main DB's
 * Counter for customerId/workerId/bookingId, or the admin DB's AdminCounter
 * for adminId. Each database's counters collection is fully independent.
 *
 * Atomic and race-safe: if two signups happen at the exact same instant,
 * MongoDB's unique _id constraint means only one `create()` can succeed
 * with the starting value — the other falls through to the $inc branch.
 */
async function getNextSequence(CounterModel, name, start = 101, step = 5) {
  try {
    const created = await CounterModel.create({ _id: name, seq: start });
    return created.seq;
  } catch (err) {
    if (err.code === 11000) {
      // counter already exists — increment it atomically
      const counter = await CounterModel.findByIdAndUpdate(
        name,
        { $inc: { seq: step } },
        { new: true }
      );
      return counter.seq;
    }
    throw err;
  }
}

async function generateCustomerId(models) {
  return getNextSequence(models.Counter, 'customerId');
}

async function generateWorkerId(models) {
  return getNextSequence(models.Counter, 'workerId');
}

async function generateBookingId(models) {
  return getNextSequence(models.Counter, 'bookingId');
}

async function generateAdminId(models) {
  // Uses the ADMIN database's own counter — separate sequence entirely
  return getNextSequence(models.AdminCounter, 'adminId');
}

module.exports = {
  getNextSequence,
  generateCustomerId,
  generateWorkerId,
  generateBookingId,
  generateAdminId,
};
