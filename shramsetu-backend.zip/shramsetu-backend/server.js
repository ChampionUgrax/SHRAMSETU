require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDatabases = require('./config/db');
const { initModels } = require('./models');

const authRoutes = require('./routes/authRoutes');
const bookingRoutes = require('./routes/bookingRoutes');
const adminRoutes = require('./routes/adminRoutes');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'ShramSetu API running (two-database setup)' });
});

app.use('/api/auth', authRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/admin', adminRoutes);

app.use((req, res) => {
  res.status(404).json({ message: 'Route not found' });
});

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong', error: err.message });
});

const PORT = process.env.PORT || 5000;

connectDatabases()
  .then(({ mainConn, adminConn }) => {
    initModels(mainConn, adminConn);
    console.log('[MongoDB] ID counters ready (customerId/workerId/bookingId in main DB, adminId in admin DB — all start at 101, +5 each)');
    app.listen(PORT, () => {
      console.log(`[ShramSetu API] running on http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error('Failed to connect to one or both databases:', err.message);
    process.exit(1);
  });
