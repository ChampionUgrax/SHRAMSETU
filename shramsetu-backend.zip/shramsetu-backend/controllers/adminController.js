const { getModels } = require('../models');
const logActivity = require('../utils/logActivity');

// GET /api/admin/customers  (main DB)
exports.getAllCustomers = async (req, res) => {
  try {
    const models = getModels();
    const customers = await models.Customer.find().select('-passwordHash').sort({ createdAt: -1 });
    res.json(customers);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch customers', error: err.message });
  }
};

// GET /api/admin/workers  (main DB)
exports.getAllWorkers = async (req, res) => {
  try {
    const models = getModels();
    const { skillCategory, available } = req.query;
    const filter = {};
    if (skillCategory) filter.skillCategory = skillCategory;
    if (available === 'true') filter.isAvailable = true;
    const workers = await models.Worker.find(filter).select('-passwordHash').sort({ createdAt: -1 });
    res.json(workers);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch workers', error: err.message });
  }
};

// PUT /api/admin/workers/:workerId/verify  (main DB — admin verifies/suspends a worker)
// body: { isVerified?, isActive? }
exports.updateWorkerStatus = async (req, res) => {
  try {
    const models = getModels();
    const { isVerified, isActive } = req.body;
    const update = {};
    if (isVerified !== undefined) update.isVerified = isVerified;
    if (isActive !== undefined) update.isActive = isActive;

    const worker = await models.Worker.findOneAndUpdate(
      { workerId: Number(req.params.workerId) }, update, { new: true }
    ).select('-passwordHash');
    if (!worker) return res.status(404).json({ message: 'Worker not found' });

    await logActivity(models, {
      userId: req.user.businessId, role: 'admin', name: req.user.name, email: req.user.email,
      action: isActive === false ? 'worker_suspended' : 'worker_verified',
      details: { workerId: worker.workerId },
    });

    res.json(worker);
  } catch (err) {
    res.status(500).json({ message: 'Failed to update worker', error: err.message });
  }
};

// GET /api/admin/bookings  (main DB, filter + paginate)
exports.getAllBookings = async (req, res) => {
  try {
    const models = getModels();
    const { status, page = 1, limit = 20 } = req.query;
    const filter = {};
    if (status) filter.status = status;

    const bookings = await models.Booking.find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));
    const total = await models.Booking.countDocuments(filter);

    res.json({ bookings, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch bookings', error: err.message });
  }
};

// GET /api/admin/logs  (main DB, filterable)
exports.getLogs = async (req, res) => {
  try {
    const models = getModels();
    const { role, action, limit = 50 } = req.query;
    const filter = {};
    if (role) filter.role = role;
    if (action) filter.action = action;

    const logs = await models.ActivityLog.find(filter).sort({ createdAt: -1 }).limit(Number(limit));
    res.json(logs);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch logs', error: err.message });
  }
};

// GET /api/admin/logs/:role/:userId  (full trace for one specific user, e.g. /customer/101)
exports.getLogsForUser = async (req, res) => {
  try {
    const models = getModels();
    const { role, userId } = req.params;
    const logs = await models.ActivityLog.find({ role, userId: Number(userId) }).sort({ createdAt: -1 });
    res.json(logs);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch user logs', error: err.message });
  }
};

// GET /api/admin/overview  (KPI counts — pulls from BOTH databases)
exports.getOverview = async (req, res) => {
  try {
    const models = getModels();
    const [totalCustomers, totalWorkers, totalAdmins, bookingsByStatus, ticketCountToday] = await Promise.all([
      models.Customer.countDocuments(),          // main DB
      models.Worker.countDocuments(),             // main DB
      models.Admin.countDocuments(),               // admin DB (separate connection)
      models.Booking.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]), // main DB
      models.ActivityLog.countDocuments({
        createdAt: { $gte: new Date(new Date().setHours(0, 0, 0, 0)) },
      }), // main DB
    ]);

    res.json({ totalCustomers, totalWorkers, totalAdmins, bookingsByStatus, actionsToday: ticketCountToday });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch overview', error: err.message });
  }
};
