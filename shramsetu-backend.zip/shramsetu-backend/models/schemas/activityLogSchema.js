const { Schema } = require('mongoose');

// Every login + every traceable action gets written here, so admin can pull
// the full history for any customer or worker by their numeric id.
const activityLogSchema = new Schema(
  {
    userId: { type: Number, required: true }, // customerId, workerId, or adminId
    role: { type: String, enum: ['customer', 'worker', 'admin'], required: true },
    name: String,
    email: String,
    action: { type: String, required: true }, // register, login, booking_created, status_changed, worker_verified, worker_suspended...
    details: Schema.Types.Mixed,
  },
  { timestamps: true }
);

activityLogSchema.index({ userId: 1, role: 1 });
activityLogSchema.index({ createdAt: -1 });

module.exports = activityLogSchema;
